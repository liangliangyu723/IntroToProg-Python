#-------------------------------------------------#
# Title: Working with Functions and Class
# Dev:   KYu
# Date:  May 3, 2018
# ChangeLog: (Who, When, What)
#-------------------------------------------------#

#-- Data --#
objFile = open("C:\\Users\\dj411e\\Desktop\\_PythonClass\\Todo.txt")
strData = ""
dicRow = {}
lstTable = []
i = int(0)
chk = int(0)
lineList = objFile.readlines()
count = len(lineList)

# Step 1 - Load data from a file
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
# Add the each dictionary "row" to a python list "table"
# print(lineList)

def loadData():
    '''
        load the any data in file ToDo.txt into a python Dictionary
    '''
    # in a text file called ToDo.txt
    objFile = open("C:\\Users\\dj411e\\Desktop\\_PythonClass\\Todo.txt")
    dicRow = {}
    lineList = objFile.readlines()
    count = len(lineList)
    for i in range(0, count):
        dicRow["ToDo_{0}".format(i)] = lineList[i].strip()
    return dicRow

class userOptions(object):
    '''
           This class contains methods for processing user options
    '''
    # Define the method
    @staticmethod
    def showData():
        print("Current ToDo list is:" + "\n" + str(lstTable))
    # Define the method
    @staticmethod
    def addItem():
        userInput1 = str(input("Enter ToDo Item Description:"))
        userInput2 = str(input("Enter Priority:"))
        # Store data in list new row
        lstNewRow = ["ToDo_" + str(len(lstTable)), userInput1 + "," + userInput2]
        lstTable.append(lstNewRow)
        print("New Item" + "ToDo_" + str(len(lstTable) - 1) + " Added!" + '\n' + str(lstTable))
    # Define the method
    @staticmethod
    def removeItem():
        chk = int(0)
        userInput3 = str(input("Enter the item ID to be removed:"))
        if chk != 0: chk = 0
        for i, v in enumerate(lstTable):
            if v[0] == 'ToDo_' + userInput3:
                lstTable.remove(lstTable[i])
                chk = chk + 1
                print("Item" + " ToDo_" + userInput3 + " Deleted!" + '\n' + str(lstTable))
        if chk == 0:
            print("No Item Found!")
    # Define the method
    @staticmethod
    def saveFile():
        objFile = open("C:\\Users\\dj411e\\Desktop\\_PythonClass\\Todo.txt", "w")
        for i, v in enumerate(lstTable):
            objFile.write(str(v[1]) + "\n")
        objFile.close()
        print("Data saved in Todo.txt")
        # Save data to new file Todo_lstTable.txt in the form of list
        objFile = open("C:\\Users\\dj411e\\Desktop\\_PythonClass\\Todo_lstTable.txt", "w")
        for item in lstTable:
            objFile.write(str(item) + "\n")
        objFile.close()
    # Define the method
    @staticmethod
    def exitProgram():
        # Exit the program
        answer = input("Would you like to exit this program? (y/n)")
        return answer


print("Data from ToDo.txt file in the form of dictionary:" + "\n" + str(loadData()))

for key, value in loadData().items():
    lstRow = [key,value]
    lstTable.append(lstRow)

print("Convert the Data to list object:" + "\n" + str(lstTable))

#-- Input/Output --#
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))

# -- Processing --#
    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        userOptions.showData()
        continue
    # Step 4 - Add a new item to the list/Table
    elif(strChoice.strip() == '2'):
        userOptions.addItem()
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        userOptions.removeItem()
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        userOptions.saveFile()
        continue
    # Step 7 - Exit program
    elif(strChoice == '5'):
        #userOptions.exitProgram()
        if userOptions.exitProgram().lower() == "y": break
        else:continue
